#!/usr/bin/env python3
"""Turns the upstream Sourccey Mk.V URDF into an armless Gazebo Harmonic robot with an RPLIDAR A1 on the dome.

Reads sourccey/SourcceyMkV.urdf (unchanged upstream file), writes sourccey_sim.urdf for ROS and
sourccey_sim.sdf for Gazebo. Rerun after editing anything here:  python3 make_sourccey.py
Mesh paths in both outputs start with MESH_ROOT, which the launch file swaps for the real folder.
"""
import copy
import math
import os
import subprocess
import xml.etree.ElementTree as ET

import numpy as np

HERE = os.path.dirname(os.path.realpath(__file__))
SRC = os.path.join(HERE, 'sourccey')
MESH_ROOT = 'file://SOURCCEY_DIR'

# base_link is the assembly origin: its z=0 is the bottom plate and the robot faces (+x, -y).
FORWARD_YAW = math.pi / 4  # rotates that facing onto +x of the new root frame
WHEEL_RADIUS = 0.0525
GROUND_Z = -0.117          # lowest point of the wheels, in base_link
DOME_TOP_Z = 0.912         # flat 11 cm pad on the robot's centre axis
ARMS_ROOT = 'Linear_Actuator_Assembly_v1_1'  # the lift column, which carries both arms
WHEELS = {  # joint: (fwd, left) sign of where the wheel must be, roller direction from gz's mecanum example
    'front_left_wheel': (1, 1, '1 -1 0'),
    'front_right_wheel': (1, -1, '1 1 0'),
    'rear_left_wheel': (-1, 1, '1 1 0'),
    'rear_right_wheel': (-1, -1, '1 -1 0'),
}
LIDAR_SENSOR = """
  <gazebo reference="laser">
    <sensor name="rplidar_a1" type="gpu_lidar">
      <always_on>true</always_on>
      <update_rate>7.5</update_rate>
      <topic>scan</topic>
      <gz_frame_id>laser</gz_frame_id>
      <lidar>
        <scan><horizontal><samples>720</samples><min_angle>-3.14159</min_angle><max_angle>3.14159</max_angle></horizontal></scan>
        <range><min>0.15</min><max>12.0</max></range>
        <noise><type>gaussian</type><mean>0.0</mean><stddev>0.01</stddev></noise>
      </lidar>
    </sensor>
  </gazebo>"""


def transform(origin):
    if origin is None:
        return np.eye(4)
    x = [float(v) for v in origin.get('xyz', '0 0 0').split()]
    r, p, y = [float(v) for v in origin.get('rpy', '0 0 0').split()]
    cr, sr, cp, sp, cy, sy = math.cos(r), math.sin(r), math.cos(p), math.sin(p), math.cos(y), math.sin(y)
    m = np.eye(4)
    m[:3, :3] = (np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]]) @ np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]])
                 @ np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]]))
    m[:3, 3] = x
    return m


def add(parent, tag, **attrs):
    return ET.SubElement(parent, tag, attrs)


def cylinder_inertial(link, mass, r, h):
    i = add(link, 'inertial')
    add(i, 'mass', value=str(mass))
    a, c = mass * (3 * r * r + h * h) / 12, mass * r * r / 2
    add(i, 'inertia', ixx=str(a), ixy='0', ixz='0', iyy=str(a), iyz='0', izz=str(c))


def stl_centre(path):
    data = open(path, 'rb').read()
    n = np.frombuffer(data, '<u4', 1, 80)[0]
    tris = np.frombuffer(data, np.dtype([('n', '<3f4'), ('v', '<9f4'), ('a', '<u2')]), n, 84)['v'].reshape(-1, 3)
    return (tris.min(0) + tris.max(0)) / 2


def remove_subtree(robot, root):
    for joint in robot.findall('joint'):
        if joint.find('child').get('link') == root:
            robot.remove(joint)
        elif joint.find('parent').get('link') == root:
            remove_subtree(robot, joint.find('child').get('link'))
    robot.remove(next(l for l in robot.findall('link') if l.get('name') == root))


def build_urdf():
    robot = ET.parse(os.path.join(SRC, 'SourcceyMkV.urdf')).getroot()
    robot.set('name', 'sourccey')
    remove_subtree(robot, ARMS_ROOT)  # delete this line to get the arms back
    links = {l.get('name'): l for l in robot.findall('link')}
    joints = robot.findall('joint')
    parent_of = {j.find('child').get('link'): j for j in joints}

    def link_pose(name):
        m = np.eye(4)
        while name in parent_of:
            m = transform(parent_of[name].find('origin')) @ m
            name = parent_of[name].find('parent').get('link')
        return m

    for link in links.values():
        for c in link.findall('collision'):  # 845k triangles is far too heavy for physics
            link.remove(c)
        for mesh in link.iter('mesh'):
            mesh.set('filename', 'file://' + os.path.join(SRC, mesh.get('filename')))
        for visual in link.findall('visual'):  # upstream defines no materials
            add(add(visual, 'material', name='sourccey_grey'), 'color', rgba='0.55 0.58 0.62 1')

    forward = np.array([math.cos(FORWARD_YAW), -math.sin(FORWARD_YAW), 0])
    left = np.array([math.sin(FORWARD_YAW), math.cos(FORWARD_YAW), 0])
    for joint in joints:
        name = joint.get('name')
        if joint.get('type') in ('revolute', 'prismatic'):  # no controllers, so hold the default pose
            joint.set('type', 'fixed')
            for tag in ('axis', 'limit', 'dynamics'):
                for e in joint.findall(tag):
                    joint.remove(e)
        elif name in WHEELS:
            fwd_sign, left_sign, _ = WHEELS[name]
            hub = joint.find('child').get('link')
            wheel = next(j.find('child').get('link') for j in joints
                         if j.find('parent').get('link') == hub and 'Mecanum' in j.find('child').get('link'))
            visual = links[wheel].find('visual')
            mesh = visual.find('geometry/mesh')
            centre = stl_centre(mesh.get('filename')[len('file://'):]) * float((mesh.get('scale') or '1').split()[0])
            local = transform(visual.find('origin')) @ np.append(centre, 1)
            world = (link_pose(wheel) @ local)[:3]
            assert math.copysign(1, world @ forward) == fwd_sign and math.copysign(1, world @ left) == left_sign, name
            assert abs(world[2] - (GROUND_Z + WHEEL_RADIUS)) < 0.002, name

            collision = add(links[hub], 'collision')  # hub is what the wheel joint moves
            hub_centre = (np.linalg.inv(link_pose(hub)) @ np.append(world, 1))[:3]
            add(collision, 'origin', xyz=' '.join(f'{v:.6f}' for v in hub_centre))
            add(add(collision, 'geometry'), 'sphere', radius=str(WHEEL_RADIUS))

            # gz's MecanumDrive assumes +spin rolls forward on every wheel
            axis = joint.find('axis')
            xyz = np.array([float(v) for v in axis.get('xyz').split()])
            if xyz @ left < 0:
                axis.set('xyz', ' '.join(str(-v) for v in xyz))

    base = links['base_link']  # the body as one simple shape, wheels aside
    collision = add(base, 'collision')
    add(collision, 'origin', xyz='0 0 0.47')
    add(add(collision, 'geometry'), 'cylinder', radius='0.23', length='0.88')

    add(robot, 'link', name='base_footprint')
    joint = add(robot, 'joint', name='base_footprint_joint', type='fixed')
    add(joint, 'parent', link='base_footprint')
    add(joint, 'child', link='base_link')
    add(joint, 'origin', xyz=f'0 0 {-GROUND_Z}', rpy=f'0 0 {FORWARD_YAW}')

    laser = add(robot, 'link', name='laser')
    for tag in ('visual', 'collision'):
        e = add(laser, tag)
        add(add(e, 'geometry'), 'cylinder', radius='0.035', length='0.04')
    material = add(laser.find('visual'), 'material', name='lidar_black')
    add(material, 'color', rgba='0.05 0.05 0.05 1')
    cylinder_inertial(laser, 0.19, 0.035, 0.04)
    joint = add(robot, 'joint', name='laser_joint', type='fixed')
    add(joint, 'parent', link='base_link')
    add(joint, 'child', link='laser')
    add(joint, 'origin', xyz=f'0 0 {DOME_TOP_Z + 0.02}', rpy=f'0 0 {-FORWARD_YAW}')

    robot.extend(ET.fromstring(f'<robot>{LIDAR_SENSOR}</robot>'))
    wheel_y = 0.156
    wheel_x = 0.146
    plugins = f"""<gazebo>
      <plugin filename="gz-sim-mecanum-drive-system" name="gz::sim::systems::MecanumDrive">
        <front_left_joint>front_left_wheel</front_left_joint>
        <front_right_joint>front_right_wheel</front_right_joint>
        <back_left_joint>rear_left_wheel</back_left_joint>
        <back_right_joint>rear_right_wheel</back_right_joint>
        <wheel_separation>{2 * wheel_y}</wheel_separation>
        <wheelbase>{2 * wheel_x}</wheelbase>
        <wheel_radius>{WHEEL_RADIUS}</wheel_radius>
        <min_acceleration>-1</min_acceleration>
        <max_acceleration>1</max_acceleration>
        <topic>cmd_vel</topic>
        <odom_topic>odom</odom_topic>
        <tf_topic>/tf</tf_topic>
        <frame_id>odom</frame_id>
        <child_frame_id>base_footprint</child_frame_id>
      </plugin>
      <plugin filename="gz-sim-joint-state-publisher-system" name="gz::sim::systems::JointStatePublisher">
        <topic>joint_states</topic>
      </plugin>
    </gazebo>"""
    robot.append(ET.fromstring(plugins))
    return robot


def build_sdf(urdf_path):
    text = subprocess.run(['gz', 'sdf', '-p', urdf_path], check=True, capture_output=True, text=True).stdout
    ET.register_namespace('gz', 'http://gazebosim.org/schema')
    sdf = ET.fromstring(text.replace('<model name=', '<model xmlns:gz="http://gazebosim.org/schema" name=', 1))
    model = sdf.find('model')
    for name, (_, _, roller) in WHEELS.items():
        child = next(j.find('child').text for j in model.findall('joint') if j.get('name') == name)
        link = next(l for l in model.findall('link') if l.get('name') == child)
        collision = link.find('collision')
        for s in collision.findall('surface'):
            collision.remove(s)
        ode = add(add(add(collision, 'surface'), 'friction'), 'ode')
        add(ode, 'mu').text = '1.0'
        add(ode, 'mu2').text = '0.0'
        fdir = add(ode, 'fdir1', **{'{http://gazebosim.org/schema}expressed_in': 'base_footprint'})
        fdir.text = roller
    return sdf


urdf_path = os.path.join(HERE, 'sourccey_sim.urdf')
sdf_path = os.path.join(HERE, 'sourccey_sim.sdf')
ET.ElementTree(build_urdf()).write(urdf_path)
ET.ElementTree(build_sdf(urdf_path)).write(sdf_path)
for path in (urdf_path, sdf_path):
    with open(path) as f:
        text = f.read()
    with open(path, 'w') as f:
        f.write(text.replace('file://' + SRC, MESH_ROOT))
print('wrote sourccey_sim.urdf and sourccey_sim.sdf')
