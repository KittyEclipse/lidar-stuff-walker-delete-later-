#!/usr/bin/env python3
# Sourccey Mk.V with a simulated RPLIDAR A1 in Gazebo Harmonic -> slam_toolbox -> RViz.
# Regenerate the robot with make_sourccey.py after changing it.
#   ros2 launch lidar_sim/lidar_sim.launch.py
# Args: drive:=false (steer it yourself with teleop_twist_keyboard)  gui:=false  rviz:=false
#       gpu:=false (render Gazebo on the CPU if the GPU path misbehaves)
import os
import subprocess
import sys

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, ExecuteProcess, GroupAction,
                            IncludeLaunchDescription, SetEnvironmentVariable)
from launch.conditions import IfCondition, UnlessCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.actions import Node

HERE = os.path.dirname(os.path.realpath(__file__))
SLAM_DIR = os.path.join(os.path.dirname(HERE), 'lidar_slam')
WORLD = os.path.join(HERE, 'room.sdf')
GPU = LaunchConfiguration('gpu')
LOCAL_SDF = os.path.join(HERE, 'sourccey_local.sdf')
WSL_GPU = os.path.exists('/dev/dxg')


def refuse_second_sim():
    # A second copy shares the first one's topics and clock, and its Gazebo window aborts on a GL error.
    if subprocess.run(['pgrep', '-f', '^gz sim'], capture_output=True).returncode == 0:
        sys.exit('Gazebo is already running. Close it, or find it with: pgrep -af "gz sim"')


def load_robot(name):
    with open(os.path.join(HERE, name)) as f:
        return f.read().replace('file://SOURCCEY_DIR', 'file://' + os.path.join(HERE, 'sourccey'))


def generate_launch_description():
    refuse_second_sim()
    robot_description = load_robot('sourccey_sim.urdf')
    with open(LOCAL_SDF, 'w') as f:
        f.write(load_robot('sourccey_sim.sdf'))
    sim_time = {'use_sim_time': True}
    gz_flags = PythonExpression(["'-r -v2 ' if '", LaunchConfiguration('gui'),
                                 "' == 'true' else '-r -s --headless-rendering -v2 '"])

    return LaunchDescription([
        # Reasons for the Cyclone settings are in the file.
        SetEnvironmentVariable('CYCLONEDDS_URI', 'file://' + os.path.join(SLAM_DIR, 'cyclonedds.xml')),

        DeclareLaunchArgument('drive', default_value='true'),
        DeclareLaunchArgument('gui', default_value='true'),
        DeclareLaunchArgument('rviz', default_value='true'),

        DeclareLaunchArgument('gpu', default_value='true'),

        # Gazebo only. Under WSL, Mesa's d3d12 driver offers OpenGL 4.2 and Gazebo's ogre2 wants 4.3+,
        # so the GPU path needs the version override. RViz runs on the GPU without any of this.
        GroupAction(scoped=True, actions=[
            *([SetEnvironmentVariable('GALLIUM_DRIVER', 'd3d12', condition=IfCondition(GPU)),
               SetEnvironmentVariable('MESA_GL_VERSION_OVERRIDE', '4.5', condition=IfCondition(GPU)),
               SetEnvironmentVariable('MESA_GLSL_VERSION_OVERRIDE', '450', condition=IfCondition(GPU))]
              if WSL_GPU else []),
            SetEnvironmentVariable('GALLIUM_DRIVER', 'llvmpipe', condition=UnlessCondition(GPU)),
            SetEnvironmentVariable('LIBGL_ALWAYS_SOFTWARE', '1', condition=UnlessCondition(GPU)),
            SetEnvironmentVariable('QT_QPA_PLATFORM', 'xcb'),
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(os.path.join(
                    get_package_share_directory('ros_gz_sim'), 'launch', 'gz_sim.launch.py')),
                launch_arguments={'gz_args': [gz_flags, WORLD], 'on_exit_shutdown': 'true'}.items(),
            ),
        ]),

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[{'robot_description': robot_description}, sim_time],
        ),
        Node(
            package='ros_gz_sim',
            executable='create',
            arguments=['-file', LOCAL_SDF, '-name', 'sourccey',
                       '-x', '-1.5', '-y', '-1.0', '-z', '0.02'],
            output='screen',
        ),
        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            parameters=[{'config_file': os.path.join(HERE, 'gz_bridge.yaml')}, sim_time],
        ),

        Node(
            package='slam_toolbox',
            executable='async_slam_toolbox_node',
            name='slam_toolbox',
            parameters=[os.path.join(SLAM_DIR, 'slam_params.yaml'), sim_time],
            output='screen',
        ),
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            condition=IfCondition(LaunchConfiguration('rviz')),
            arguments=['-d', os.path.join(HERE, 'lidar_sim.rviz')],
            parameters=[sim_time],
        ),
        ExecuteProcess(
            cmd=['python3', os.path.join(HERE, 'wander.py')],
            condition=IfCondition(LaunchConfiguration('drive')),
        ),
    ])
