#!/usr/bin/env python3
"""Drives the sim robot around on its own: go forward, turn away from whatever is in front."""
import math
import random

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan

FRONT = math.radians(40)
STOP_DIST = 0.7  # the body is about 0.27 m in radius, this leaves room to turn


class Wander(Node):
    def __init__(self):
        super().__init__('wander')
        self.pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.create_subscription(LaserScan, 'scan', self.on_scan, qos_profile_sensor_data)
        self.turn = 0.0

    def on_scan(self, scan):
        front, left, right = [], [], []
        for i, r in enumerate(scan.ranges):
            if not math.isfinite(r) or r < scan.range_min:
                continue
            a = scan.angle_min + i * scan.angle_increment
            if abs(a) < FRONT:
                front.append(r)
            elif FRONT <= a < 2 * FRONT:
                left.append(r)
            elif -2 * FRONT < a <= -FRONT:
                right.append(r)
        cmd = Twist()
        if min(front, default=12.0) < STOP_DIST:
            if self.turn == 0.0:  # commit to one direction until the way is clear
                self.turn = 0.6 if min(left, default=12.0) >= min(right, default=12.0) else -0.6
            cmd.angular.z = self.turn
        else:
            self.turn = 0.0
            cmd.linear.x = 0.3
            cmd.angular.z = random.uniform(-0.1, 0.1)
        self.pub.publish(cmd)


rclpy.init()
rclpy.spin(Wander())
